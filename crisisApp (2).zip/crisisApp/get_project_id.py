from ibm_watsonx_ai import APIClient

# Your exact key
my_api_key = "YizQ7HqDcRFAfB6YR8zoIaJqYR4hYqermgnDnwrD"

credentials = {
    "url": "https://us-south.ml.cloud.ibm.com",
    "apikey": my_api_key
}

print("\n🔍 Connecting to IBM Cloud...")
try:
    client = APIClient(credentials)
    print("✅ Connection Successful! Here are your projects:\n")
    
    client.projects.list(limit=5)
    
except Exception as e:
    print(f"❌ Error: {e}")